import pygame

pygame.init()
WIDTH = 500   # Chiều ngang (W: Width)
HEIGHT = 500  # Chiều dọc   (H: Height)
BLACK = (0, 0, 0)  # Màu Đen
FPS = 30      # Số cảnh mỗi giây (frame per second)
screen = pygame.display.set_mode([WIDTH, HEIGHT])
clock = pygame.time.Clock()

# Bắt đầu game
running = True
while running:
    # Tạo hình nền
    screen.fill(BLACK)
    background = pygame.image.load("sprites/background.png").convert_alpha()
    background = pygame.transform.scale(background, (WIDTH, HEIGHT))
    screen.blit(background, (0, 0))

    # Người chơi có tắt màn hình game chưa
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Hiển thị hình ảnh trong game kích cỡ: 50 x 80px
    image = pygame.image.load("sprites/trau.png")
    image = pygame.transform.scale(image, (50, 80))
    
    # Toạ độ (x=200, y=200)
    screen.blit(image, (200, 200))
    pygame.display.flip()
    clock.tick(FPS)

# Ket thuc game
pygame.quit()
