import pygame

pygame.init()
WIDTH = 500   # Chiều ngang (W: Width)
HEIGHT = 500  # Chiều dọc   (H: Height)
BLACK = (0, 0, 0)  # Màu Đen
FPS = 30      # Số cảnh mỗi giây (frame per second)
screen = pygame.display.set_mode([WIDTH, HEIGHT])
clock = pygame.time.Clock()
class Door:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        # Kích thước cửa (door) 80 x 80 px
        sprite = pygame.image.load("sprites/door.png")
        self.image = pygame.transform.scale(sprite, (80, 80))

class Robot:
    def __init__(self, x, y, x_heading, y_heading, hinh_anh):
        self.x = x
        self.y = y
        self.x_heading = x_heading
        self.y_heading = y_heading
        # Kích thước Robot 60 x 60 px
        sprite = pygame.image.load(hinh_anh)
        self.image = pygame.transform.scale(sprite, (60, 60))

class Player:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        # Kích thước trẩu (player) 50 x 80 px
        sprite = pygame.image.load("sprites/trau.png")
        self.image = pygame.transform.scale(sprite, (50, 80))

# Khởi tạo đối tượng Trẩu + Cửa (Door) + Robot
trau = Player(100, 250)
door = Door(375, 20)
robots = [
    Robot(100, 400, 5, 0, "sprites/robot1.png"),
    Robot(300, 300, 0, 5, "sprites/robot2.png"),
    Robot(200, 200, 10, 2, "sprites/robot3.png"),
    Robot(100, 100, -2, -5, "sprites/robot4.png")
]

#---------------------------------------------------------
# Bắt đầu game
running = True
while running:
    # Tạo hình nền
    screen.fill(BLACK)
    background = pygame.image.load("sprites/background.png").convert_alpha()
    background = pygame.transform.scale(background, (WIDTH, HEIGHT))
    screen.blit(background, (0, 0))

    # Người chơi có tắt màn hình game chưa
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    #----------------------------------------
    # Hiển thị vị trí của các đối tượng
    screen.blit(door.image, (door.x, door.y))
    screen.blit(trau.image, (trau.x, trau.y))
    for robot in robots:
        screen.blit(robot.image, (robot.x, robot.y))

    pygame.display.flip()
    clock.tick(FPS)

# Ket thuc game
pygame.quit()
