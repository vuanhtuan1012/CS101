import pygame as pg
import sys
import os

# dinh nghia cac hang so
WIDTH, HEIGHT = 1800, 1350  # kich thuoc cua so chuong trinh
IMG_WIDTH, IMG_HEIGHT = 900, 675  # kich thuoc anh nhan vat
TITLE = "Vũ Khánh Chi @ CS101"  # tieu de cua so
FPS = 5  # so khung hinh tren giay
ASSETS_PATH = os.path.join(".", "assests")  # thu muc chua tai nguyen
MUSIC_PATH = os.path.join(ASSETS_PATH, "music.wav")  # file nhac
# cac chuyen dong
MOVES = {
    "move0": {
        "time": 0.5,
        "sprites": [
            "0.png"
            ]
        },
    "move1": {
        "time": 0.95,
        "sprites": [
            "1.1.png",
            "1.2.png",
            "1.3.png"
            ]
        },
    "move2": {
        "time": 0.95,
        "sprites": [
            "2.1.png",
            "2.2.png"
            ]
        },
    "move3": {
        "time": 0.95,
        "sprites": [
            "3.1.png",
            "3.2.png"
            ]
        },
    "move4": {
        "time": 0.95,
        "sprites": [
            "4.1.png",
           "4.2.png"
            ]
        },
    "move5": {
        "time": 0.95,
        "sprites": [
            "5.1.png",
            "5.2.png"
            ]
        },
    "move6": {
        "time": 0.95,
        "sprites": [
            "6.1.png",
            "6.2.png"
            ]
        },
    "move7": {
        "time": 0.95,
        "sprites": [
            "7.1.png",
            "7.2.png",
            "7.3.png"
            ]
        }
    }

PROCEDURE = [
    'move0',
    'move1',
    'move2',
    'move3',
    'move4',
    'move1',
    'move2',
    'move3',
    'move4',
    'move5',
    'move6',
    'move3',
    'move4',
    'move5',
    'move6',
    'move3',
    'move7',
    'move7',
    'move7'
    ]


# khai bao lop nhan vat
class Dancer(pg.sprite.Sprite):
    def __init__(self, path, topleft = [0, 0]):
        super().__init__()
        self.moves = {}
        self.cur_move = 0
        self.cur_sprite = 0
        self.fps = 0
        self.count = 0
        self.image = None
        self.rect = None
        self.path = path
        self.topleft = topleft

    def load_images(self):
        count = 0
        for k, v in MOVES.items():
            count += 1
            sprites = []
            for sprite in v["sprites"]:
                img_path = os.path.join(ASSETS_PATH, self.path, k, sprite)
                sprites.append(pg.image.load(img_path))
            self.moves[k] = {
                "time": v["time"],
                "sprites": sprites
                }

    def draw_image(self, sprite):
        self.image = sprite
        self.image = pg.transform.scale(self.image, (IMG_WIDTH, IMG_HEIGHT))
        self.rect = self.image.get_rect()
        self.rect.topleft = self.topleft

    def init(self):
        self.load_images()
        move = PROCEDURE[self.cur_move]
        self.draw_image(self.moves[move]["sprites"][self.cur_sprite])

    def update(self):
        no_moves = len(PROCEDURE)
        if self.cur_move >= no_moves:
            self.cur_move = 0
        no_sprites = len(self.moves[PROCEDURE[self.cur_move]]["sprites"])
        time_of_move = self.moves[PROCEDURE[self.cur_move]]["time"]
        self.fps = FPS * time_of_move // no_sprites
        if self.count >= self.fps:
            if self.cur_sprite < no_sprites:
                self.next_sprite()
            else:
                self.next_move()
        self.count += 1

    def next_sprite(self):
        sprite = self.moves[PROCEDURE[self.cur_move]]["sprites"][self.cur_sprite]
        self.draw_image(sprite)
        self.count = 0
        self.cur_sprite += 1

    def next_move(self):
        self.cur_move += 1
        self.cur_sprite = 0


def main():
    pg.init()  # khoi tao pygame
    clock = pg.time.Clock()  # bo dem thoi gian
    # tao mat phang chua toan bo phan hien thi
    surface = pg.display.set_mode((WIDTH, HEIGHT))
    pg.display.set_caption(TITLE)  # tieu de cua so

    # choi nhac
    pg.mixer.init()
    pg.mixer.music.load(MUSIC_PATH)
    pg.mixer.music.play(-1)

    # khoi tao nhan vat
    ma_ket_1 = Dancer("Ma_Ket")
    ma_ket_1.init()
    kim_nguu_1 = Dancer("Kim_Nguu", [900, 0])
    kim_nguu_1.init()
    ma_ket_2 = Dancer("Ma_Ket", [900, 675])
    ma_ket_2.init()
    kim_nguu_2 = Dancer("Kim_Nguu", [0, 675])
    kim_nguu_2.init()

    # dua cac nhan vat vao nhom
    sprites = pg.sprite.Group()
    sprites.add(ma_ket_1)
    sprites.add(kim_nguu_1)
    sprites.add(ma_ket_2)
    sprites.add(kim_nguu_2)

    while True:
        # thoat chuong trinh neu dong cua so
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()

        # cap nhat hanh dong cua nhan vat
        sprites.update()
        # ve len surface
        sprites.draw(surface)
        # cap nhat lai noi dung cua toan bo phan hien thi
        pg.display.flip()
        # cap nhat bo dem thoi gian
        clock.tick(FPS)  # giu cho game chay cham hon FPS/giay


if __name__ == "__main__":
    main()